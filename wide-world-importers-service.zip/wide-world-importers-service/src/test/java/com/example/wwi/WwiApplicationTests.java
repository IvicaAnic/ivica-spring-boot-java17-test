package com.example.wwi;

import com.example.wwi.controller.WwiController;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class WwiApplicationTests {

    @Autowired
    private WwiController wwiController;

    @Test
    void contextLoads() {
        assertThat(wwiController).isNotNull();
    }
}
