package com.example.wwi.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "Stock Item", schema = "Dimension")
public class StockItem {

    @Id
    @Column(name = "[Stock Item Key]")
    private Integer stockItemKey;

    @Column(name = "[WWI Stock Item ID]", nullable = false)
    private Integer wwiStockItemId;

    @Column(name = "[Stock Item]", nullable = false, length = 100)
    private String stockItem;

    @Column(name = "Color", nullable = false, length = 20)
    private String color;

    @Column(name = "[Selling Package]", nullable = false, length = 50)
    private String sellingPackage;

    @Column(name = "[Buying Package]", nullable = false, length = 50)
    private String buyingPackage;

    @Column(name = "Brand", nullable = false, length = 50)
    private String brand;

    @Column(name = "Size", nullable = false, length = 20)
    private String size;

    @Column(name = "[Lead Time Days]", nullable = false)
    private Integer leadTimeDays;

    @Column(name = "[Quantity Per Outer]", nullable = false)
    private Integer quantityPerOuter;

    @Column(name = "[Is Chiller Stock]", nullable = false)
    private Boolean isChillerStock;

    @Column(name = "Barcode", length = 50)
    private String barcode;

    @Column(name = "[Tax Rate]", nullable = false, precision = 18, scale = 3)
    private BigDecimal taxRate;

    @Column(name = "[Unit Price]", nullable = false, precision = 18, scale = 2)
    private BigDecimal unitPrice;

    @Column(name = "[Recommended Retail Price]", precision = 18, scale = 2)
    private BigDecimal recommendedRetailPrice;

    @Column(name = "[Typical Weight Per Unit]", nullable = false, precision = 18, scale = 3)
    private BigDecimal typicalWeightPerUnit;

    @Lob
    @Column(name = "Photo")
    private byte[] photo;

    @Column(name = "[Valid From]", nullable = false)
    private LocalDateTime validFrom;

    @Column(name = "[Valid To]", nullable = false)
    private LocalDateTime validTo;

    @Column(name = "[Lineage Key]", nullable = false)
    private Integer lineageKey;

    public Integer getStockItemKey() { return stockItemKey; }
    public void setStockItemKey(Integer stockItemKey) { this.stockItemKey = stockItemKey; }
    public Integer getWwiStockItemId() { return wwiStockItemId; }
    public void setWwiStockItemId(Integer wwiStockItemId) { this.wwiStockItemId = wwiStockItemId; }
    public String getStockItem() { return stockItem; }
    public void setStockItem(String stockItem) { this.stockItem = stockItem; }
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
    public String getSellingPackage() { return sellingPackage; }
    public void setSellingPackage(String sellingPackage) { this.sellingPackage = sellingPackage; }
    public String getBuyingPackage() { return buyingPackage; }
    public void setBuyingPackage(String buyingPackage) { this.buyingPackage = buyingPackage; }
    public String getBrand() { return brand; }
    public void setBrand(String brand) { this.brand = brand; }
    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }
    public Integer getLeadTimeDays() { return leadTimeDays; }
    public void setLeadTimeDays(Integer leadTimeDays) { this.leadTimeDays = leadTimeDays; }
    public Integer getQuantityPerOuter() { return quantityPerOuter; }
    public void setQuantityPerOuter(Integer quantityPerOuter) { this.quantityPerOuter = quantityPerOuter; }
    public Boolean getIsChillerStock() { return isChillerStock; }
    public void setIsChillerStock(Boolean isChillerStock) { this.isChillerStock = isChillerStock; }
    public String getBarcode() { return barcode; }
    public void setBarcode(String barcode) { this.barcode = barcode; }
    public BigDecimal getTaxRate() { return taxRate; }
    public void setTaxRate(BigDecimal taxRate) { this.taxRate = taxRate; }
    public BigDecimal getUnitPrice() { return unitPrice; }
    public void setUnitPrice(BigDecimal unitPrice) { this.unitPrice = unitPrice; }
    public BigDecimal getRecommendedRetailPrice() { return recommendedRetailPrice; }
    public void setRecommendedRetailPrice(BigDecimal recommendedRetailPrice) { this.recommendedRetailPrice = recommendedRetailPrice; }
    public BigDecimal getTypicalWeightPerUnit() { return typicalWeightPerUnit; }
    public void setTypicalWeightPerUnit(BigDecimal typicalWeightPerUnit) { this.typicalWeightPerUnit = typicalWeightPerUnit; }
    public byte[] getPhoto() { return photo; }
    public void setPhoto(byte[] photo) { this.photo = photo; }
    public LocalDateTime getValidFrom() { return validFrom; }
    public void setValidFrom(LocalDateTime validFrom) { this.validFrom = validFrom; }
    public LocalDateTime getValidTo() { return validTo; }
    public void setValidTo(LocalDateTime validTo) { this.validTo = validTo; }
    public Integer getLineageKey() { return lineageKey; }
    public void setLineageKey(Integer lineageKey) { this.lineageKey = lineageKey; }
}
