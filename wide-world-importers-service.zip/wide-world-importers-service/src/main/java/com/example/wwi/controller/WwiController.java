package com.example.wwi.controller;

import com.example.wwi.model.City;
import com.example.wwi.model.Customer;
import com.example.wwi.model.StockItem;
import com.example.wwi.repository.CityRepository;
import com.example.wwi.repository.CustomerRepository;
import com.example.wwi.repository.StockItemRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/wwi")
@Tag(name = "Wide World Importers API", description = "Endpunkte für Dimensionen und Daten des DW")
public class WwiController {

    private final CityRepository cityRepository;
    private final CustomerRepository customerRepository;
    private final StockItemRepository stockItemRepository;

    public WwiController(CityRepository cityRepository, CustomerRepository customerRepository, StockItemRepository stockItemRepository) {
        this.cityRepository = cityRepository;
        this.customerRepository = customerRepository;
        this.stockItemRepository = stockItemRepository;
    }

    @GetMapping("/cities")
    @Operation(summary = "Alle Städte abrufen", description = "Liefert eine Liste aller Städte aus der Dimension.City Tabelle.")
    public List<City> getAllCities() {
        return cityRepository.findAll();
    }

    @GetMapping("/customers")
    @Operation(summary = "Alle Kunden abrufen", description = "Liefert eine Liste aller Kunden aus der Dimension.Customer Tabelle.")
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    @GetMapping("/stock-items")
    @Operation(summary = "Alle Lagerartikel abrufen", description = "Liefert eine Liste aller Artikel aus der Dimension.Stock Item Tabelle.")
    public List<StockItem> getAllStockItems() {
        return stockItemRepository.findAll();
    }
}
