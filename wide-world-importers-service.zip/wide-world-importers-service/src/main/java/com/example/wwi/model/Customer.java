package com.example.wwi.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "Customer", schema = "Dimension")
public class Customer {

    @Id
    @Column(name = "[Customer Key]")
    private Integer customerKey;

    @Column(name = "[WWI Customer ID]", nullable = false)
    private Integer wwiCustomerId;

    @Column(name = "Customer", nullable = false, length = 100)
    private String customerName;

    @Column(name = "[Bill To Customer]", nullable = false, length = 100)
    private String billToCustomer;

    @Column(name = "Category", nullable = false, length = 50)
    private String category;

    @Column(name = "[Buying Group]", nullable = false, length = 50)
    private String buyingGroup;

    @Column(name = "[Primary Contact]", nullable = false, length = 50)
    private String primaryContact;

    @Column(name = "[Postal Code]", nullable = false, length = 10)
    private String postalCode;

    @Column(name = "[Valid From]", nullable = false)
    private LocalDateTime validFrom;

    @Column(name = "[Valid To]", nullable = false)
    private LocalDateTime validTo;

    @Column(name = "[Lineage Key]", nullable = false)
    private Integer lineageKey;

    public Integer getCustomerKey() { return customerKey; }
    public void setCustomerKey(Integer customerKey) { this.customerKey = customerKey; }
    public Integer getWwiCustomerId() { return wwiCustomerId; }
    public void setWwiCustomerId(Integer wwiCustomerId) { this.wwiCustomerId = wwiCustomerId; }
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    public String getBillToCustomer() { return billToCustomer; }
    public void setBillToCustomer(String billToCustomer) { this.billToCustomer = billToCustomer; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getBuyingGroup() { return buyingGroup; }
    public void setBuyingGroup(String buyingGroup) { this.buyingGroup = buyingGroup; }
    public String getPrimaryContact() { return primaryContact; }
    public void setPrimaryContact(String primaryContact) { this.primaryContact = primaryContact; }
    public String getPostalCode() { return postalCode; }
    public void setPostalCode(String postalCode) { this.postalCode = postalCode; }
    public LocalDateTime getValidFrom() { return validFrom; }
    public void setValidFrom(LocalDateTime validFrom) { this.validFrom = validFrom; }
    public LocalDateTime getValidTo() { return validTo; }
    public void setValidTo(LocalDateTime validTo) { this.validTo = validTo; }
    public Integer getLineageKey() { return lineageKey; }
    public void setLineageKey(Integer lineageKey) { this.lineageKey = lineageKey; }
}
