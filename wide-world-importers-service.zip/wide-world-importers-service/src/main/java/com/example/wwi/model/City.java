package com.example.wwi.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "City", schema = "Dimension")
public class City {

    @Id
    @Column(name = "[City Key]")
    private Integer cityKey;

    @Column(name = "[WWI City ID]", nullable = false)
    private Integer wwiCityId;

    @Column(name = "City", nullable = false, length = 50)
    private String cityName;

    @Column(name = "[State Province]", nullable = false, length = 50)
    private String stateProvince;

    @Column(name = "Country", nullable = false, length = 60)
    private String country;

    @Column(name = "Continent", nullable = false, length = 30)
    private String continent;

    @Column(name = "[Sales Territory]", nullable = false, length = 50)
    private String salesTerritory;

    @Column(name = "Region", nullable = false, length = 30)
    private String region;

    @Column(name = "Subregion", nullable = false, length = 30)
    private String subregion;

    @Column(name = "[Latest Recorded Population]", nullable = false)
    private Long latestRecordedPopulation;

    @Column(name = "[Valid From]", nullable = false)
    private LocalDateTime validFrom;

    @Column(name = "[Valid To]", nullable = false)
    private LocalDateTime validTo;

    @Column(name = "[Lineage Key]", nullable = false)
    private Integer lineageKey;

    public Integer getCityKey() { return cityKey; }
    public void setCityKey(Integer cityKey) { this.cityKey = cityKey; }
    public Integer getWwiCityId() { return wwiCityId; }
    public void setWwiCityId(Integer wwiCityId) { this.wwiCityId = wwiCityId; }
    public String getCityName() { return cityName; }
    public void setCityName(String cityName) { this.cityName = cityName; }
    public String getStateProvince() { return stateProvince; }
    public void setStateProvince(String stateProvince) { this.stateProvince = stateProvince; }
    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }
    public String getContinent() { return continent; }
    public void setContinent(String continent) { this.continent = continent; }
    public String getSalesTerritory() { return salesTerritory; }
    public void setSalesTerritory(String salesTerritory) { this.salesTerritory = salesTerritory; }
    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }
    public String getSubregion() { return subregion; }
    public void setSubregion(String subregion) { this.subregion = subregion; }
    public Long getLatestRecordedPopulation() { return latestRecordedPopulation; }
    public void setLatestRecordedPopulation(Long latestRecordedPopulation) { this.latestRecordedPopulation = latestRecordedPopulation; }
    public LocalDateTime getValidFrom() { return validFrom; }
    public void setValidFrom(LocalDateTime validFrom) { this.validFrom = validFrom; }
    public LocalDateTime getValidTo() { return validTo; }
    public void setValidTo(LocalDateTime validTo) { this.validTo = validTo; }
    public Integer getLineageKey() { return lineageKey; }
    public void setLineageKey(Integer lineageKey) { this.lineageKey = lineageKey; }
}
